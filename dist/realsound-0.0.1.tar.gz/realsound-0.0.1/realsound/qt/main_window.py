import sys
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtMultimedia import (
    QCapturableWindow,
    QMediaCaptureSession,
    QScreenCapture,
    QVideoFrame,
    QWindowCapture,
)
from PySide6.QtWidgets import (
    QGridLayout,
    QLabel,
    QListView,
    QMessageBox,
    QPushButton,
    QWidget,
    QApplication,
)
from PySide6.QtCore import QCoreApplication

from realsound.qt.cv_settings import CVSettingsListWidget


class MainWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.lab1 = QLabel("1", self)
        self.lab2 = QLabel("2", self)
        self.lab3 = QLabel("3", self)
        self.lab4 = QLabel("4", self)
        self.lab5 = QLabel("5", self)
        self.lab6 = QLabel("6", self)

        self.settings = CVSettingsListWidget(default_config="cv_settings.json")

        self.main_layout = QGridLayout(self)
        self.main_layout.addWidget(self.lab1, 0, 0)
        self.main_layout.addWidget(self.lab2, 2, 0)
        self.main_layout.addWidget(self.lab3, 3, 0)
        self.main_layout.addWidget(self.lab4, 0, 1)
        self.main_layout.addWidget(self.lab5, 2, 1)
        self.main_layout.addWidget(self.settings, 3, 1)

        self.main_layout.setColumnStretch(1, 1)
        self.main_layout.setRowStretch(1, 1)
        self.main_layout.setColumnMinimumWidth(0, 200)
        self.main_layout.setColumnMinimumWidth(1, 200)
        self.main_layout.setRowMinimumHeight(1, 1)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    QCoreApplication.setApplicationName("Testin")
    test = MainWindow()
    test.show()
    sys.exit(app.exec())
