from .cv_slider import CVSliderWidget
from .cv_settings import CVSettingsListWidget
